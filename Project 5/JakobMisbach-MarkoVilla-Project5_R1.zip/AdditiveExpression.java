import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;

public class AdditiveExpression extends AbstractCompoundExpression {

    /**
     * Creates an instance of Additive Expression
     * @param children children of the additive expression
     * @param parent parent of the additive expsression
     */
    AdditiveExpression(final List<Expression> children, final CompoundExpression parent){
        super(children, parent, "+");
    }

    /**
     * Creates a deep copy of the expression
     * @return the deep copy that was created
     */
    @Override
    public Expression deepCopy() {
        //Create a new instance of the children array
        List<Expression> newArr = new ArrayList<>();
        //Add deep copies of the children to the new array
        super.getChildren().forEach(e -> {
            Expression newE = e.deepCopy();
            newE.setParent(this);
            newArr.add(newE);
        });
        //Return a new instance of AdditiveExpression
        return new AdditiveExpression(newArr, null);
    }

    /**
     * Combines common symbols to simplify the tree
     */
    @Override
    public void flatten() {
        //If we are at the head of the tree we cannot be flattened
        //So we just proceed to flattening children
        if(parent == null){
            //Flatten the children
            for(Expression child : super.getChildren()){
                child.flatten();
            }
        }
        ListIterator<Expression> iter = super.getChildren().listIterator();
        while (iter.hasNext()){
            Expression child = iter.next();
            //Flatten the current child
            child.flatten();
            //Check if the child is an instance of AdditiveExpression
            if(child instanceof AdditiveExpression){
                //Remove the child from children
                iter.remove();
                //Set the parents of the child to our parent
                ((AdditiveExpression) child).getChildren().forEach(e -> e.setParent(this));
                //Add the children to our children
                ((AdditiveExpression) child).getChildren().forEach(iter::add);
            }
        }
    }
}
